from setuptools import setup
setup(
  name = 'changeOffice',
  packages = ['changeOffice'],
  version = '0.1',
  description = 'change msOffice format from xls to xlsx, doc to docx, ppt to pptx',
    long_description=open('README.md').read(),
  author = 'Wang Qi',
  author_email = 'wangmarkqi@gmail.com',
  url = 'https://github.com/wangmarkqi/changeOffice',
  download_url = 'https://github.com/wangmarkqi/changeOffice.git',
    install_requires=[ 'pywin32>=214'],
  keywords = ['excel', 'word', 'ppt','xls to xlsx','doc to docx','ppt to pptx'],
  classifiers = [],
)